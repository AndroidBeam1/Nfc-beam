package com.example.nfcbeam

import android.app.Activity
import android.app.AlertDialog
import android.content.ComponentName
import android.content.ContentValues
import android.content.Intent
import android.net.Uri
import android.nfc.NfcAdapter
import android.nfc.Tag
import android.nfc.cardemulation.CardEmulation
import android.nfc.tech.IsoDep
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.provider.OpenableColumns
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.webkit.MimeTypeMap
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.IOException
import java.nio.ByteBuffer

class MainActivity : Activity() {
    private var nfc: NfcAdapter? = null
    private lateinit var status: TextView
    private lateinit var beam: BeamView
    private lateinit var sendBtn: Button
    private lateinit var recvBtn: Button
    private lateinit var cancelBtn: Button
    private val ui = Handler(Looper.getMainLooper())

    private var mode = 0 // 0 idle, 1 sending, 2 receiving
    private var payload: ByteArray? = null
    private var fileName = ""

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        nfc = NfcAdapter.getDefaultAdapter(this)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setBackgroundColor(0xFF101820.toInt())
            setPadding(dp(24), dp(48), dp(24), dp(24))
        }
        root.addView(TextView(this).apply {
            text = "NFC Beam"; textSize = 28f; setTextColor(0xFFFFFFFF.toInt())
        })
        beam = BeamView(this)
        root.addView(beam, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        status = TextView(this).apply {
            text = "Send a file or get ready to receive one."
            textSize = 16f; gravity = Gravity.CENTER
            setTextColor(0xFFFFFFFF.toInt())
        }
        root.addView(status)

        fun btn(label: String, onClick: () -> Unit): Button {
            val bt = Button(this).apply { text = label; setOnClickListener { onClick() } }
            root.addView(bt, LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { topMargin = dp(12) })
            return bt
        }
        sendBtn = btn("Send a file") { pickFile() }
        recvBtn = btn("Receive") { startReceiving() }
        cancelBtn = btn("Cancel") { stopAll(); setStatus("Cancelled.") }
        cancelBtn.visibility = View.GONE

        setContentView(root)
    }

    private fun setStatus(s: String) { ui.post { status.text = s } }

    // ---------- NFC checks ----------
    private fun ensureNfc(): Boolean {
        val n = nfc
        if (n == null) { status.text = "This phone has no NFC."; return false }
        if (!n.isEnabled) {
            status.text = "Turn NFC on, then come back and try again."
            startActivity(Intent(Settings.ACTION_NFC_SETTINGS))
            return false
        }
        return true
    }

    private fun setBusy() {
        sendBtn.isEnabled = false; recvBtn.isEnabled = false
        cancelBtn.visibility = View.VISIBLE
        beam.active = true
    }

    private fun stopAll() {
        mode = 0
        Inbox.listening = false
        Inbox.onProgress = null; Inbox.onDone = null; Inbox.onLost = null
        Inbox.reset()
        try { nfc?.disableReaderMode(this) } catch (e: Exception) {}
        beam.active = false
        window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        sendBtn.isEnabled = true; recvBtn.isEnabled = true
        cancelBtn.visibility = View.GONE
        payload = null
    }

    // ---------- Sending ----------
    private fun pickFile() {
        if (!ensureNfc()) return
        val i = Intent(Intent.ACTION_GET_CONTENT).apply {
            type = "*/*"; addCategory(Intent.CATEGORY_OPENABLE)
        }
        startActivityForResult(Intent.createChooser(i, "Choose a file to send"), 1)
    }

    override fun onActivityResult(req: Int, res: Int, data: Intent?) {
        super.onActivityResult(req, res, data)
        val uri = data?.data
        if (req != 1 || res != RESULT_OK || uri == null) return
        setStatus("Reading file...")
        Thread {
            try {
                val name = queryName(uri)
                val out = ByteArrayOutputStream()
                val buf = ByteArray(8192)
                val ins = contentResolver.openInputStream(uri) ?: throw IOException()
                ins.use {
                    while (true) {
                        val r = it.read(buf)
                        if (r < 0) break
                        out.write(buf, 0, r)
                        if (out.size() > Proto.MAX_BYTES) break
                    }
                }
                if (out.size() > Proto.MAX_BYTES) { setStatus("File is too big (max 5 MB)."); return@Thread }
                ui.post { payload = out.toByteArray(); fileName = name; startSending() }
            } catch (e: Exception) {
                setStatus("Couldn't read that file.")
            }
        }.start()
    }

    private fun queryName(u: Uri): String {
        var n: String? = null
        contentResolver.query(u, null, null, null, null)?.use { c ->
            val i = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
            if (c.moveToFirst() && i >= 0) n = c.getString(i)
        }
        return (n ?: "file").replace('/', '_').replace('\\', '_')
    }

    private fun startSending() {
        mode = 1
        setBusy()
        status.text = "Touch the back of the other phone\n(it must be on Receive)."
        enableReader()
    }

    private fun enableReader() {
        nfc?.enableReaderMode(
            this,
            { tag -> onTag(tag) },
            NfcAdapter.FLAG_READER_NFC_A or NfcAdapter.FLAG_READER_NFC_B or
                NfcAdapter.FLAG_READER_SKIP_NDEF_CHECK,
            null
        )
    }

    private fun ok(r: ByteArray) =
        r.size >= 2 && r[r.size - 2] == 0x90.toByte() && r[r.size - 1] == 0.toByte()

    private fun apdu(ins: Int, body: ByteArray): ByteArray {
        val a = ByteArray(5 + body.size)
        a[0] = 0x80.toByte(); a[1] = ins.toByte(); a[4] = body.size.toByte()
        System.arraycopy(body, 0, a, 5, body.size)
        return a
    }

    private fun onTag(tag: Tag) {
        val data = payload ?: return
        val iso = IsoDep.get(tag) ?: return
        try {
            iso.connect()
            iso.timeout = 5000
            if (!ok(iso.transceive(Proto.SELECT))) {
                setStatus("The other phone isn't ready. Tap Receive on it, then touch again.")
                return
            }
            var nameB = fileName.toByteArray(Charsets.UTF_8)
            if (nameB.size > 200) nameB = nameB.copyOf(200)
            val start = ByteBuffer.allocate(4 + nameB.size).putInt(data.size).put(nameB).array()
            if (!ok(iso.transceive(apdu(0x10, start)))) { setStatus("The other phone refused. Try again."); return }

            var seq = 0
            var off = 0
            while (off < data.size) {
                val n = minOf(Proto.CHUNK, data.size - off)
                val body = ByteBuffer.allocate(2 + n).putShort(seq.toShort()).put(data, off, n).array()
                if (!ok(iso.transceive(apdu(0x20, body)))) { setStatus("Transfer error. Touch again to retry."); return }
                off += n; seq++
                if (seq % 10 == 0) {
                    val pct = off * 100L / data.size
                    setStatus("Sending... $pct%\nKeep the phones together.")
                }
            }
            if (ok(iso.transceive(apdu(0x30, ByteArray(0))))) {
                val nm = fileName
                ui.post { stopAll(); status.text = "Sent \"$nm\"." }
            } else {
                setStatus("Transfer didn't finish. Touch again to retry.")
            }
        } catch (e: IOException) {
            setStatus("Connection lost. Move apart and touch again.")
        } finally {
            try { iso.close() } catch (e: Exception) {}
        }
    }

    // ---------- Receiving ----------
    private fun startReceiving() {
        if (!ensureNfc()) return
        if (!packageManager.hasSystemFeature("android.hardware.nfc.hce")) {
            status.text = "This phone can't receive over NFC (no card emulation)."
            return
        }
        mode = 2
        setBusy()
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        status.text = "Ready. Touch the other phone\n(it must be on Send)."
        Inbox.reset()
        Inbox.onProgress = { got, total ->
            status.text = "Receiving... ${got * 100L / total}%\nKeep the phones together."
        }
        Inbox.onLost = { status.text = "Connection lost. Ask them to touch again." }
        Inbox.onDone = { name, data -> askAccept(name, data) }
        Inbox.listening = true
    }

    private fun askAccept(name: String, data: ByteArray) {
        val clean = name.replace('/', '_').replace('\\', '_').ifEmpty { "file" }
        AlertDialog.Builder(this)
            .setTitle("Receive file?")
            .setMessage("\"$clean\" (${data.size / 1024 + 1} KB) arrived over NFC. Save it to Downloads?")
            .setPositiveButton("Save") { _, _ ->
                status.text = try { "Saved: " + save(clean, data) } catch (e: Exception) { "Couldn't save the file." }
            }
            .setNegativeButton("Discard") { _, _ -> status.text = "Discarded." }
            .setOnDismissListener { stopAll() }
            .show()
    }

    private fun save(name: String, data: ByteArray): String {
        if (Build.VERSION.SDK_INT >= 29) {
            val ext = name.substringAfterLast('.', "").lowercase()
            val mime = MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext) ?: "application/octet-stream"
            val v = ContentValues().apply {
                put(MediaStore.MediaColumns.DISPLAY_NAME, name)
                put(MediaStore.MediaColumns.MIME_TYPE, mime)
            }
            val uri = contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v)
                ?: throw IOException()
            contentResolver.openOutputStream(uri)!!.use { it.write(data) }
            return "Downloads/$name"
        }
        val dir = getExternalFilesDir("Received") ?: filesDir
        dir.mkdirs()
        File(dir, name).writeBytes(data)
        return "${dir.absolutePath}/$name"
    }

    // ---------- Lifecycle ----------
    override fun onResume() {
        super.onResume()
        try {
            CardEmulation.getInstance(nfc).setPreferredService(this, ComponentName(this, BeamService::class.java))
        } catch (e: Exception) {}
        if (mode == 1) enableReader()
    }

    override fun onPause() {
        try { CardEmulation.getInstance(nfc).unsetPreferredService(this) } catch (e: Exception) {}
        if (mode == 1) try { nfc?.disableReaderMode(this) } catch (e: Exception) {}
        super.onPause()
    }
}
